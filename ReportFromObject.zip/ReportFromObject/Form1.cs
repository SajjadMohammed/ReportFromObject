﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace ReportFromObject
{
    public partial class Form1 : Form
    {
        
        private List<StudentsInfo> std = new List<StudentsInfo>();
        private int id = 1;

        public Form1()
        {
            InitializeComponent();

            id_txt.Text = id.ToString();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //std.Sort((x, y) => (x.S_FName.CompareTo(y.S_FName)));
            //or 
            std.OrderBy(name => name.S_FName);

            ReportForm repf = new ReportForm();
            repf.StudentsInfoBindingSource.DataSource = std;
            repf.reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
            repf.reportViewer1.ShowToolBar = false;
            repf.reportViewer1.RefreshReport();
            repf.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            std.Add(new StudentsInfo
                            {
                                S_ID = id,
                                S_FName = name_txt.Text,
                                S_Address = addr_txt.Text,
                                S_BDate = DateTime.Parse(dob_txt.Text)
                            });

            id_txt.Text = (++id).ToString();

            name_txt.Text = dob_txt.Text = addr_txt.Text = "";
        }
    }
}