﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReportFromObject
{
    public class StudentsInfo
    {
        // تسلس الطالب
        public int S_ID
        { set; get; }
        // اسم الطالب
        public string S_FName
        { set; get; }
        // تاريخ ولادة الطالب
        public DateTime S_BDate
        { set; get; }
        // عنوان الطالب
        public string S_Address
        { set; get; }
    }
}
